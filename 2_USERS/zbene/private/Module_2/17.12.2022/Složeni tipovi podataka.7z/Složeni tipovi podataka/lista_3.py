nasa_lista = [154, 'tekst', 'jos jedan tekst', 3.14, True, 'Pa opet tekst']

brojevi = [2, 7, 13, 23, 16, 9, 0, 11, 73, 92]

for broj in brojevi: #za svaki broj unutar liste brojevi
    print(broj, end=' ')
print()
print(brojevi)

#print(type(brojevi[1])) provjera dal je string ili integer

for element in nasa_lista:
    print(element)