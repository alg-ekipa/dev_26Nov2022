rijec = 'programiranje'

for slovo in rijec:
    print(slovo, end=' ')

print()
print(f'Broj slova u riječi {rijec} je {len(rijec)}.')


rijec_lista = list(rijec)
print(rijec_lista)